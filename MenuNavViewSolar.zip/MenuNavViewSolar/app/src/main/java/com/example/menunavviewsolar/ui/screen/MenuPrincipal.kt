package com.example.menunavviewsolar.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.menunavviewsolar.ui.navegacion.Screen
import com.example.menunavviewsolar.ui.views.MainViewModel


@Composable
fun MenuPrincipal(
    navController: NavController,
    viewModel: MainViewModel
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        TextField(
            value = viewModel.parametro1,
            onValueChange = { viewModel.parametro1 = it },
            label = { Text("Parámetro 1") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        TextField(
            value = viewModel.parametro2,
            onValueChange = { viewModel.parametro2 = it },
            label = { Text("Parámetro 2") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { navController.navigate(Screen.Pantalla1.route) }) {
            Text("Ir a Pantalla 1")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = {
                navController.navigate("pantalla2/${viewModel.parametro1}")
            }
        ) {
            Text("Ir a Pantalla 2")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = {
                navController.navigate("pantalla3/${viewModel.parametro1}/${viewModel.parametro2}")
            }
        ) {
            Text("Ir a Pantalla 3")
        }
    }
}