package com.example.menunavviewsolar.ui.views

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

// ViewModel principal
class MainViewModel : ViewModel() {
    var parametro1 by mutableStateOf("")
    var parametro2 by mutableStateOf("")
    var contador by mutableStateOf(0)

    fun incrementarContador() {
        contador++
    }
}

