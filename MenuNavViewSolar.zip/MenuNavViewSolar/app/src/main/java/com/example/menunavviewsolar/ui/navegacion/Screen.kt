package com.example.menunavviewsolar.ui.navegacion

// Pantallas selladas
sealed class Screen(val route: String) {
    object Menu : Screen("menu")
    object Pantalla1 : Screen("pantalla1")
    object Pantalla2 : Screen("pantalla2/{param1}")
    object Pantalla3 : Screen("pantalla3/{param1}/{param2}")
}