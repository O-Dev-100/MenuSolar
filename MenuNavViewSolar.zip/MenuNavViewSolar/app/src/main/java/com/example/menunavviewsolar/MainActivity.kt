package com.example.menunavviewsolar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.menunavviewsolar.ui.navegacion.Screen
import com.example.menunavviewsolar.ui.screen.MenuPrincipal
import com.example.menunavviewsolar.ui.screen.Pantalla1
import com.example.menunavviewsolar.ui.screen.Pantalla2
import com.example.menunavviewsolar.ui.screen.Pantalla3
import com.example.menunavviewsolar.ui.views.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()
            val viewModel: MainViewModel = viewModel()

            NavHost(navController = navController, startDestination = Screen.Menu.route) {
                // Menú Principal
                composable(Screen.Menu.route) {
                    MenuPrincipal(navController, viewModel)
                }

                // Pantalla 1 con contador y fondo amarillo
                composable(Screen.Pantalla1.route) {
                    Pantalla1(navController)
                }

                // Pantalla 2 con parámetro1
                composable(
                    route = Screen.Pantalla2.route,
                    arguments = listOf(navArgument("param1") { type = NavType.StringType })
                ) { backStackEntry ->
                    val param1 = backStackEntry.arguments?.getString("param1") ?: ""
                    Pantalla2(navController, param1)
                }

                // Pantalla 3 con parámetro1 y parámetro2
                composable(
                    route = Screen.Pantalla3.route,
                    arguments = listOf(
                        navArgument("param1") { type = NavType.StringType },
                        navArgument("param2") { type = NavType.StringType }
                    )
                ) { backStackEntry ->
                    val param1 = backStackEntry.arguments?.getString("param1") ?: ""
                    val param2 = backStackEntry.arguments?.getString("param2") ?: ""
                    Pantalla3(navController, param1, param2)
                }
            }
        }
    }
}